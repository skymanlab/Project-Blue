package com.skyman.billiarddata.management.friend.database;

import android.content.Context;

import com.skyman.billiarddata.management.projectblue.database.ProjectBlueDBHelper;

public class FriendDbHelper extends ProjectBlueDBHelper {

    // constructor
    public FriendDbHelper(Context context) {
        super(context);
    }
}
