package com.skyman.billiarddata.developer;

public enum Display {
    ON, OFF
}
