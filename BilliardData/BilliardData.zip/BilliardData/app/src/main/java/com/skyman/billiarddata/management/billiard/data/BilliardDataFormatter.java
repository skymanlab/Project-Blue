package com.skyman.billiarddata.management.billiard.data;

import com.skyman.billiarddata.management.projectblue.data.ProjectBlueDataFormatter;

public class BilliardDataFormatter extends ProjectBlueDataFormatter {

}
