package com.skyman.billiarddata.management.player.database;

import android.content.Context;

import com.skyman.billiarddata.management.projectblue.database.ProjectBlueDBHelper;

public class PlayerDbHelper extends ProjectBlueDBHelper {

    public PlayerDbHelper(Context context) {
        super(context);
    }
}
