package com.skyman.billiarddata.management.friend.data;

import com.skyman.billiarddata.management.projectblue.data.ProjectBlueDataFormatter;

public class FriendDataFormatter extends ProjectBlueDataFormatter {

}
