package com.skyman.billiarddata.management.user.database;

import android.content.Context;

import com.skyman.billiarddata.management.projectblue.database.ProjectBlueDBHelper;

public class UserDbHelper extends ProjectBlueDBHelper {

    // constructor
    public UserDbHelper(Context context) {
        super(context);
    }
}
