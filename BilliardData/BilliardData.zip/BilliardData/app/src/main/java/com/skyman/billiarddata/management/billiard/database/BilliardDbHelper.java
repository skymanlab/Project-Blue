package com.skyman.billiarddata.management.billiard.database;

import android.content.Context;

import com.skyman.billiarddata.management.projectblue.database.ProjectBlueDBHelper;

public class BilliardDbHelper extends ProjectBlueDBHelper {

    // constructor
    public BilliardDbHelper(Context context) {
        super(context);
    }
}
