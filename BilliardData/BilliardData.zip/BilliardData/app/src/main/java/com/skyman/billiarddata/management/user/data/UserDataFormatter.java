package com.skyman.billiarddata.management.user.data;

import com.skyman.billiarddata.management.projectblue.data.ProjectBlueDataFormatter;

public class UserDataFormatter extends ProjectBlueDataFormatter {


}
